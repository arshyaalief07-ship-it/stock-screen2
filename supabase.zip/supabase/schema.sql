create extension if not exists pgcrypto;

create table if not exists public.stocks (
  id uuid primary key default gen_random_uuid(),
  symbol text not null unique,
  name text,
  sector text,
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint symbol_format check (symbol ~ '^[A-Z0-9.-]+(\.JK)?$')
);

create table if not exists public.daily_prices (
  id bigint generated always as identity primary key,
  symbol text not null references public.stocks(symbol) on update cascade on delete cascade,
  trade_date date not null,
  open numeric,
  high numeric,
  low numeric,
  close numeric not null,
  adj_close numeric,
  volume bigint,
  source text not null default 'Yahoo Finance',
  fetched_at timestamptz not null default now(),
  unique(symbol, trade_date)
);

create index if not exists idx_daily_prices_symbol_date
  on public.daily_prices(symbol, trade_date desc);

create table if not exists public.daily_signals (
  symbol text primary key references public.stocks(symbol) on update cascade on delete cascade,
  trade_date date not null,
  close numeric,
  change_pct numeric,
  volume bigint,
  avg_volume_20 bigint,
  rsi_14 numeric,
  macd numeric,
  macd_signal numeric,
  sma_20 numeric,
  sma_50 numeric,
  sma_200 numeric,
  atr_pct numeric,
  high_20 numeric,
  low_20 numeric,
  score numeric,
  signal text,
  components jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now()
);

create index if not exists idx_daily_signals_score on public.daily_signals(score desc);
create index if not exists idx_daily_signals_trade_date on public.daily_signals(trade_date desc);

alter table public.stocks enable row level security;
alter table public.daily_prices enable row level security;
alter table public.daily_signals enable row level security;

drop policy if exists "Public read stocks" on public.stocks;
create policy "Public read stocks" on public.stocks for select using (true);
drop policy if exists "Public read prices" on public.daily_prices;
create policy "Public read prices" on public.daily_prices for select using (true);
drop policy if exists "Public read signals" on public.daily_signals;
create policy "Public read signals" on public.daily_signals for select using (true);

grant select on public.stocks, public.daily_prices, public.daily_signals to anon, authenticated;
grant all on public.stocks, public.daily_prices, public.daily_signals to service_role;
