import numpy as np
import pandas as pd

def _rsi(close: pd.Series, period: int = 14):
    delta = close.diff()
    gain = delta.clip(lower=0).ewm(alpha=1/period, adjust=False).mean()
    loss = (-delta.clip(upper=0)).ewm(alpha=1/period, adjust=False).mean()
    rs = gain / loss.replace(0, np.nan)
    return 100 - (100 / (1 + rs))

def analyze(df: pd.DataFrame):
    df = df.dropna(subset=["Close"]).copy().sort_index()
    if len(df) < 200:
        return None

    close, high, low, volume = df["Close"], df["High"], df["Low"], df["Volume"].fillna(0)
    sma20, sma50, sma200 = close.rolling(20).mean(), close.rolling(50).mean(), close.rolling(200).mean()
    ema12, ema26 = close.ewm(span=12, adjust=False).mean(), close.ewm(span=26, adjust=False).mean()
    macd = ema12 - ema26
    macd_signal = macd.ewm(span=9, adjust=False).mean()
    rsi = _rsi(close)
    prev_close = close.iloc[-2]
    change_pct = ((close.iloc[-1] / prev_close) - 1) * 100 if prev_close else 0
    tr = pd.concat([(high-low), (high-close.shift()).abs(), (low-close.shift()).abs()], axis=1).max(axis=1)
    atr = tr.rolling(14).mean()
    atr_pct = (atr.iloc[-1] / close.iloc[-1]) * 100 if close.iloc[-1] else None
    avg_vol = volume.rolling(20).mean()
    high20, low20 = high.shift(1).rolling(20).max(), low.shift(1).rolling(20).min()

    price = float(close.iloc[-1])
    s20, s50, s200 = [float(x.iloc[-1]) for x in (sma20, sma50, sma200)]
    r = float(rsi.iloc[-1]) if pd.notna(rsi.iloc[-1]) else 50.0
    m, ms = float(macd.iloc[-1]), float(macd_signal.iloc[-1])
    av = float(avg_vol.iloc[-1]) if pd.notna(avg_vol.iloc[-1]) else 0
    vol = int(volume.iloc[-1])
    h20 = float(high20.iloc[-1]) if pd.notna(high20.iloc[-1]) else price
    l20 = float(low20.iloc[-1]) if pd.notna(low20.iloc[-1]) else price
    ap = float(atr_pct) if pd.notna(atr_pct) else 0.0

    trend = (10 if price > s20 else 0) + (10 if s20 > s50 else 0) + (10 if price > s200 else 0)
    momentum = (12.5 if 50 <= r <= 70 else (7 if r > 70 else (8 if r >= 40 else 0))) + (12.5 if m > ms else 0)
    volume_score = min(20, (vol / av) * 10) if av > 0 else 0
    volatility_score = max(0, 10 - ap) if ap else 0
    structure = 15 if price > h20 else (8 if price > (h20 + l20)/2 else 0)
    score = round(trend + momentum + volume_score + volatility_score + structure, 2)
    signal = "Bullish" if score >= 70 else ("Watch" if score >= 50 else "Weak")

    return {
        "close": price, "change_pct": round(float(change_pct), 2), "volume": vol,
        "avg_volume_20": int(av), "rsi_14": round(r, 2), "macd": round(m, 4),
        "macd_signal": round(ms, 4), "sma_20": round(s20, 2),
        "sma_50": round(s50, 2), "sma_200": round(s200, 2),
        "atr_pct": round(ap, 2), "high_20": round(h20, 2), "low_20": round(l20, 2),
        "score": score, "signal": signal,
        "components": {"trend": round(trend,2), "momentum": round(momentum,2),
                       "volume": round(volume_score,2), "volatility": round(volatility_score,2),
                       "structure": round(structure,2)}
    }
