"use client";

import { useEffect, useMemo, useState } from "react";
import { Activity, ArrowDownRight, ArrowUpRight, RefreshCw, Search, Radar, TrendingUp } from "lucide-react";

type Signal = {
  symbol: string; trade_date: string; close: number; change_pct: number; volume: number;
  avg_volume_20: number; rsi_14: number; macd: number; macd_signal: number;
  sma_20: number; sma_50: number; sma_200: number; atr_pct: number;
  score: number; signal: string; updated_at: string;
};
const API = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000";
const rupiah = (n: number) => new Intl.NumberFormat("id-ID", { maximumFractionDigits: 0 }).format(n);
const compact = (n: number) => new Intl.NumberFormat("id-ID", { notation: "compact", maximumFractionDigits: 1 }).format(n);

export default function Home() {
  const [rows, setRows] = useState<Signal[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [q, setQ] = useState("");
  const [signal, setSignal] = useState("");
  const [sort, setSort] = useState("score");
  const [lastUpdated, setLastUpdated] = useState("");

  async function load() {
    setLoading(true); setError("");
    try {
      const params = new URLSearchParams({ limit: "500", sort });
      if (q.trim()) params.set("q", q.trim());
      if (signal) params.set("signal", signal);
      const res = await fetch(`${API}/api/screener?${params.toString()}`, { cache: "no-store" });
      if (!res.ok) throw new Error(`API error ${res.status}`);
      const json = await res.json();
      setRows(json.data || []);
      setLastUpdated(new Date().toLocaleString("id-ID"));
    } catch (e) {
      setError(e instanceof Error ? e.message : "Gagal mengambil data");
    } finally { setLoading(false); }
  }
  useEffect(() => { load(); /* initial load */ }, []);
  const stats = useMemo(() => ({
    total: rows.length,
    bullish: rows.filter(r => r.signal === "Bullish").length,
    watch: rows.filter(r => r.signal === "Watch").length,
    avg: rows.length ? rows.reduce((a, r) => a + Number(r.score || 0), 0) / rows.length : 0
  }), [rows]);

  return <main className="shell">
    <header className="topbar">
      <div className="brand"><div className="brand-icon"><Radar size={22}/></div><div><div className="brand-name">STOCK<span>RADAR</span></div><div className="brand-sub">INDONESIA EQUITY SCREENER</div></div></div>
      <div className="market-status"><span className="status-dot"/> DAILY DATA <span className="divider-v"/> IDX · ALL UNIVERSE</div>
    </header>

    <section className="hero">
      <div><div className="eyebrow"><Activity size={14}/> MARKET INTELLIGENCE / TECHNICAL</div>
        <h1>Temukan sinyal.<br/><span>Bukan sekadar keramaian.</span></h1>
        <p className="hero-copy">Pemindaian teknikal saham BEI berdasarkan tren, momentum, volume, volatilitas, dan struktur harga.</p>
      </div>
      <div className="hero-mark"><div className="radar-ring r1"/><div className="radar-ring r2"/><div className="radar-ring r3"/><div className="radar-core"><TrendingUp size={34}/></div></div>
    </section>

    <section className="stats">
      <div className="stat-card"><span className="stat-label">TICKER TERPANTAU</span><strong>{stats.total}</strong><small>hasil pada filter aktif</small></div>
      <div className="stat-card"><span className="stat-label">BULLISH</span><strong className="green">{stats.bullish}</strong><small>skor ≥ 70</small></div>
      <div className="stat-card"><span className="stat-label">WATCHLIST</span><strong className="yellow">{stats.watch}</strong><small>skor 50–69</small></div>
      <div className="stat-card"><span className="stat-label">RATA-RATA SKOR</span><strong>{stats.avg.toFixed(1)}<em>/100</em></strong><small>heuristik teknikal</small></div>
    </section>

    <section className="panel">
      <div className="panel-head"><div><div className="eyebrow">SCANNER / 01</div><h2>Market screener</h2></div><button className="refresh" onClick={load} disabled={loading}><RefreshCw size={15} className={loading ? "spin" : ""}/> Refresh</button></div>
      <div className="filters">
        <div className="searchbox"><Search size={16}/><input value={q} onChange={e => setQ(e.target.value)} onKeyDown={e => e.key === "Enter" && load()} placeholder="Cari kode saham..."/></div>
        <select value={signal} onChange={e => {setSignal(e.target.value);}}><option value="">Semua sinyal</option><option>Bullish</option><option>Watch</option><option>Weak</option></select>
        <select value={sort} onChange={e => setSort(e.target.value)}><option value="score">Skor tertinggi</option><option value="change_pct">Perubahan harian</option><option value="rsi_14">RSI</option><option value="volume">Volume</option></select>
        <button className="apply" onClick={load}>Terapkan filter</button>
      </div>
      {error && <div className="error">Gagal memuat data: {error}. Pastikan backend aktif dan URL API benar.</div>}
      <div className="table-wrap"><table><thead><tr><th>EMITEN</th><th>HARGA</th><th>PERUBAHAN</th><th>RSI 14</th><th>VOLUME</th><th>SKOR</th><th>SINYAL</th><th>TANGGAL DATA</th></tr></thead>
        <tbody>{loading ? <tr><td colSpan={8} className="empty">Memindai pasar...</td></tr> : rows.length === 0 ? <tr><td colSpan={8} className="empty">Belum ada data. Impor ticker dan jalankan collector terlebih dahulu.</td></tr> : rows.map(r => <tr key={r.symbol}>
          <td><b className="ticker">{r.symbol.replace(".JK","")}</b><small className="subticker">IDX EQUITY</small></td>
          <td className="price">Rp {rupiah(Number(r.close))}</td>
          <td className={Number(r.change_pct) >= 0 ? "green" : "red"}>{Number(r.change_pct) >= 0 ? <ArrowUpRight size={14}/> : <ArrowDownRight size={14}/>} {Number(r.change_pct).toFixed(2)}%</td>
          <td><span className={`rsi ${r.rsi_14 >= 70 ? "hot" : r.rsi_14 < 40 ? "cold" : ""}`}>{Number(r.rsi_14).toFixed(1)}</span></td>
          <td>{compact(Number(r.volume))}</td>
          <td><div className="score-cell"><b>{Number(r.score).toFixed(0)}</b><div className="score-track"><i style={{width:`${Math.max(0,Math.min(100,Number(r.score)))}%`}}/></div></div></td>
          <td><span className={`badge ${r.signal.toLowerCase()}`}>{r.signal}</span></td>
          <td className="date">{r.trade_date}</td>
        </tr>)}</tbody></table></div>
      <div className="table-foot"><span>MENAMPILKAN {rows.length} HASIL · URUTAN BERDASARKAN {sort.toUpperCase()}</span><span>REFRESH: {lastUpdated || "—"}</span></div>
    </section>

    <section className="method">
      <div><div className="eyebrow">METHODOLOGY / 02</div><h2>Bagaimana skor dihitung?</h2><p>Skor gabungan 0–100 untuk membantu menyaring kandidat, bukan sinyal transaksi otomatis.</p></div>
      <div className="weights">{[["Trend",30],["Momentum",25],["Volume",20],["Volatilitas",10],["Struktur harga",15]].map(([name,val])=><div className="weight" key={name}><div><span>{name}</span><b>{val}%</b></div><div className="weight-track"><i style={{width:`${val}%`}}/></div></div>)}</div>
    </section>
    <footer><span>STOCK RADAR © 2026</span><span>DATA PROVIDER: YAHOO FINANCE · DAILY / POTENTIALLY DELAYED</span><span>BUILT FOR RESEARCH, NOT EXECUTION.</span></footer>
    <p className="disclaimer">Disclaimer: Data dapat terlambat, tidak lengkap, atau berubah. Yahoo Finance bukan sumber resmi BEI. Skor teknikal bukan rekomendasi investasi. Selalu verifikasi data dan lakukan riset mandiri.</p>
  </main>;
}
