from fastapi import FastAPI, Query, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from .config import settings
from .db import supabase

app = FastAPI(title="Stock Radar API", version="1.0.0",
              description="Daily technical screener for IDX stocks. Data may be delayed.")
app.add_middleware(
    CORSMiddleware, allow_origins=settings.origins, allow_credentials=False,
    allow_methods=["GET"], allow_headers=["*"]
)

@app.get("/health")
def health():
    return {"status": "ok", "service": "stock-radar-api"}

@app.get("/api/stocks")
def stocks(q: str = "", limit: int = Query(5000, ge=1, le=10000)):
    query = supabase.table("stocks").select("symbol,name,sector,is_active").eq("is_active", True).order("symbol").limit(limit)
    if q:
        query = query.ilike("symbol", f"%{q.upper()}%")
    return {"data": query.execute().data or []}

@app.get("/api/screener")
def screener(
    q: str = "",
    signal: str = "",
    min_score: float = Query(0, ge=0, le=100),
    sort: str = "score",
    limit: int = Query(200, ge=1, le=1000)
):
    allowed = {"score", "change_pct", "rsi_14", "volume"}
    if sort not in allowed:
        raise HTTPException(status_code=400, detail=f"sort harus salah satu: {sorted(allowed)}")
    query = supabase.table("daily_signals").select(
        "symbol,trade_date,close,change_pct,volume,avg_volume_20,rsi_14,macd,macd_signal,sma_20,sma_50,sma_200,atr_pct,score,signal,components,updated_at"
    ).gte("score", min_score).order(sort, desc=True).limit(limit)
    if q:
        query = query.ilike("symbol", f"%{q.upper()}%")
    if signal:
        query = query.eq("signal", signal)
    return {"data": query.execute().data or []}
